ALTER TABLE inventory_items
  ADD COLUMN IF NOT EXISTS requires_quality_check boolean NOT NULL DEFAULT false;

ALTER TABLE purchase_order_items
  ADD COLUMN IF NOT EXISTS accepted_qty numeric(12,3),
  ADD COLUMN IF NOT EXISTS rejected_qty numeric(12,3);