-- ✅ إضافة عمود created_by_id لأوامر الشراء — كان غير موجود، ما كان يسمح
-- بتطبيق فلترة النطاق (Scope Filter) على دور "buyer" (المشتري) اللي
-- المفروض يشوف بس طلبات الشراء اللي هو أنشأها، مش كل الطلبات.
-- نفس النمط المستخدم بالفعل في sales_orders.created_by_id.

ALTER TABLE "purchase_orders"
  ADD COLUMN IF NOT EXISTS "created_by_id" integer REFERENCES "system_users"("id");

CREATE INDEX IF NOT EXISTS "purchases_created_by_idx" ON "purchase_orders"("created_by_id");
